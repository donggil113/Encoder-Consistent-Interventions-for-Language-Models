# Anonymous supplement

Contents: manuscript sources and the built PDF (paper/), code (src/), configurations
(configs/), tests (tests/), small raw result files and aggregates (results/), the claim map
(paper/claims.csv) and the third-party space word list with its Apache-2.0 license
(data_external/pplm_space/).

Not included: model/SAE weights and the WikiText files (pinned by revision in
configs/p3_contract_gpt2_res_jb_l8.json and by sha256 in configs/p3_asset_hashes.json), the
HF cache, the virtual environment, git metadata, and the authors' internal notes. Some
configuration and provenance files mention those internal notes (STATUS.md,
RESEARCH_PACKET.md, a run manifest) or approval steps; they are process records and the
referenced files are not part of this supplement. Repository commit identifiers were
replaced by "<commit>" in the shipped text files; the frozen configurations are otherwise
unchanged.

The anonymity scan removes known author strings; it is a string check, not a proof of
anonymity.
